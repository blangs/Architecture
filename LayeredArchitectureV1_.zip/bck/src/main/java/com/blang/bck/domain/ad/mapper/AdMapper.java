package com.blang.bck.domain.ad.mapper;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;

import com.blang.bck.domain.ad.dto.AdResponseDto;
import com.blang.bck.domain.ad.entity.Ad;

@Mapper
public interface AdMapper {
	public Ad selectAdById(Long id);
	public List<Ad> getAdList(Map<String, Object> params);
}
