package com.blang.bck.domain.campaign.mapper;

import org.apache.ibatis.annotations.Mapper;

import com.blang.bck.domain.campaign.entity.Campaign;

@Mapper
public interface CampaignMapper {
	public Campaign selectCampaignById(Long id);
}
