package com.blang.bck.domain.campaign.repository;

import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import com.blang.bck.domain.ad.dto.AdResponseDto;
import com.blang.bck.domain.ad.entity.Ad;
import com.blang.bck.domain.ad.mapper.AdMapper;
import com.blang.bck.domain.campaign.entity.Campaign;
import com.blang.bck.domain.campaign.mapper.CampaignMapper;
import com.blang.bck.web.vo.TBDBDW016DTO;
import com.blang.bck.web.vo.TBDBDW023DTO;

/**
 *  결론: 실무에서 Repository는 단순 연결뿐 아니라 다음을 책임집니다
 * 로직 캡슐화	여러 Mapper 호출을 묶거나 필터링, 정렬 등 로직 추가
 * 트랜잭션 처리	하나의 트랜잭션으로 묶어야 하는 DB 작업 수행
 * 캐시/로깅	AOP 기능 활용해 캐시, 로깅 삽입
 * 동적 파라미터 처리	검색 조건 등을 편하게 조립
 * 서비스로부터 MyBatis 분리	서비스 단에서 DB 세부사항을 알지 않아도 되게 함
 */
@Repository
public class CampaignRepositoryImpl implements CampaignRepository {

	/***************************************************************************
	 * 방법1
	 ***************************************************************************/
	@Inject
	private CampaignMapper campaignMapper;
	
	@Inject
	private AdMapper adMapper;
	
	@Override
	public Campaign getCampaignById(Long id) {
	    return campaignMapper.selectCampaignById(id);
	}
	
	@Override
	public Ad getAdById(Long id) {
	    return adMapper.selectAdById(id);
	}
}
