package com.blang.bck.domain.ad.repository;

import java.util.List;
import java.util.Map;

import com.blang.bck.domain.ad.entity.Ad;
import com.blang.bck.web.vo.TBDBDW023DTO;


public interface AdRepository {
    public Ad getAdById(Long id);
    
    public List<Ad> getAdList(Map<String, Object> params);
}
