package com.blang.bck.domain.campaign.repository;

import com.blang.bck.domain.ad.entity.Ad;
import com.blang.bck.domain.campaign.entity.Campaign;


public interface CampaignRepository {
    public Campaign getCampaignById(Long id);

	public Ad getAdById(Long id);
}
