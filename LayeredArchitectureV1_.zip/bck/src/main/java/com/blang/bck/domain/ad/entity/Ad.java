package com.blang.bck.domain.ad.entity;

/*****************************************************************
 * <pre>
 * &#64;프로젝트명:dbd
 * &#64;패키지명:com.blang.bck
 * &#64;클래스명:TBDBDW001DTO
 * &#64;파일명:TBDBDW001DTO.java
 * &#64;업무명:DBD회원기본
 * &#64;설명:
 * &#64;생성자:layup3
 * &#64;변경이력:
 * Version		작성자		     일자		          내용
 * --------------------------------------------------------------
 * 1.0			최태호		2021.07.25           최초작성
 * </pre>
 *****************************************************************/
public class Ad {

	private Long id; /* 광고ID */
    private String title;
    private String status;
	
	private String sysLstUpdYms; /* 시스템최종갱신일시 */
	private String sysLstUpdIdf; /* 시스템최종갱신식별자 */
	private String sysLstTrYms; /* 시스템최종거래일시 */

	private String where; /* 복합 조건문 처리 */
	private int pageNumber; /* 페이징 처리시 조회할 페이지 번호 */
	private int pageMaxLine; /* 페이징 처리시 페이당 갯수 */
	
	
	
	public Long getId() {
		return id;
	}
	public String getTitle() {
		return title;
	}
	public String getStatus() {
		return status;
	}
	public String getSysLstUpdYms() {
		return sysLstUpdYms;
	}
	public String getSysLstUpdIdf() {
		return sysLstUpdIdf;
	}
	public String getSysLstTrYms() {
		return sysLstTrYms;
	}
	public String getWhere() {
		return where;
	}
	public int getPageNumber() {
		return pageNumber;
	}
	public int getPageMaxLine() {
		return pageMaxLine;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public void setSysLstUpdYms(String sysLstUpdYms) {
		this.sysLstUpdYms = sysLstUpdYms;
	}
	public void setSysLstUpdIdf(String sysLstUpdIdf) {
		this.sysLstUpdIdf = sysLstUpdIdf;
	}
	public void setSysLstTrYms(String sysLstTrYms) {
		this.sysLstTrYms = sysLstTrYms;
	}
	public void setWhere(String where) {
		this.where = where;
	}
	public void setPageNumber(int pageNumber) {
		this.pageNumber = pageNumber;
	}
	public void setPageMaxLine(int pageMaxLine) {
		this.pageMaxLine = pageMaxLine;
	}

	

}
