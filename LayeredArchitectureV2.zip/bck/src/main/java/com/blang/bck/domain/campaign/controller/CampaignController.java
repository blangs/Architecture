package com.blang.bck.domain.campaign.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.blang.bck.domain.ad.dto.AdResponseDto;
import com.blang.bck.domain.ad.service.AdService;
import com.blang.bck.domain.campaign.dto.CampaignResponseDto;
import com.blang.bck.domain.campaign.service.CampaignService;
import com.blang.bck.global.common.codes.SuccessCode;
import com.blang.bck.global.common.response.ApiResponse;


@Controller
@RequestMapping("/app/publish")
public class CampaignController {

    private static final Logger logger = LoggerFactory.getLogger(CampaignController.class);
    private static final String RETURN_VIEW_URL = "jsp/web/DBD75039M00";

    @Inject
    private CampaignService campaignService;

	@RequestMapping(value = "/campaignServiceManagement")
	public String adServiceManagement(Model model, HttpServletRequest req) 
	{
		return RETURN_VIEW_URL;
	}
    
    @GetMapping("/camp/{id}")
    public ResponseEntity<CampaignResponseDto> campaign(@PathVariable Long id) {
    	CampaignResponseDto campaign = campaignService.getCampaign(id);
    	return ResponseEntity.ok(campaign);
    }
	
}