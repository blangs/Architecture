package com.blang.bck.domain.ad.service;

import java.util.Map;

import com.blang.bck.domain.ad.dto.AdResponseDto;


public interface AdService {

    public AdResponseDto getAd(Long id);
    
    public Map<String, Object> getAdList(Map<String, Object> params);
}
