package com.blang.bck.domain.campaign.service;



import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.blang.bck.domain.ad.entity.Ad;
import com.blang.bck.domain.ad.repository.AdRepository;
import com.blang.bck.domain.ad.repository.AdRepositoryImpl;
import com.blang.bck.domain.campaign.dto.CampaignResponseDto;
import com.blang.bck.domain.campaign.entity.Campaign;
import com.blang.bck.domain.campaign.repository.CampaignRepository;

import lombok.RequiredArgsConstructor;


@Service
@RequiredArgsConstructor
//이 어노테이션을 클래스에 붙이면,
//"final 또는 @NonNull이 붙은 모든 필드"를 파라미터로 받는 **생성자(Constructor)**를 자동으로 만들어줍니다.
public class CampaignServiceImpl implements CampaignService {

	private static final Logger logger = LoggerFactory.getLogger(CampaignService.class);

    private final CampaignRepository campaignRepository;
    private final AdRepository adRepository;
    
    
    @Override
    public CampaignResponseDto getCampaign(Long id) {
    	
    	// SELECT 광고 : 좋은예시: 서비스에서 타 인터페이스 의존으로 다른 도메인 접근 
    	Ad ad = adRepository.getAdById(id);	
    	
    	// SELECT 캠페인
    	Campaign campaign = campaignRepository.getCampaignById(ad.getId());
        
        // 좋은예시: 인터페이스 의존으로 다른 도메인 접근 
        //campaignService.getCapmId(ad.getId());

     
        if (campaign == null) {
            // 예외 처리는 상황에 따라 추가 가능
            throw new IllegalArgumentException("캠페인 정보를 찾을 수 없습니다. ID: " + id);
        }

        String statusText = null;
        if(campaign.getStatus().equals("ACTIVE")) {
        	statusText = "진행 중";
        } else if(campaign.getStatus().equals("INACTIVE")) {
        	statusText = "종료됨";
        } else {
        	statusText = "알 수 없음";
        }
        
      
        return new CampaignResponseDto(campaign.getId(), campaign.getTitle(), statusText);
    }
}
