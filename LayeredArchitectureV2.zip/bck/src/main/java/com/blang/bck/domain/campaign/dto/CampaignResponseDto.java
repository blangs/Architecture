package com.blang.bck.domain.campaign.dto;


public class CampaignResponseDto {
    

    private Long id;
    private String title;
    private String statusText; // 표현용 필드 (예: 진행 중, 종료됨 등)

    // 생성자
    public CampaignResponseDto() {}

    public CampaignResponseDto(Long id, String title, String statusText) {
        this.id = id;
        this.title = title;
        this.statusText = statusText;
    }

    // Getter & Setter
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getStatusText() {
        return statusText;
    }

    public void setStatusText(String statusText) {
        this.statusText = statusText;
    }

    @Override
    public String toString() {
        return "CampaignResponseDto{" +
                "id=" + id +
                ", title='" + title + '\'' +
                ", statusText='" + statusText + '\'' +
                '}';
    }
}
