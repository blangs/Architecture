package com.blang.bck.domain.campaign.service;

import java.util.Map;

import com.blang.bck.domain.ad.dto.AdResponseDto;
import com.blang.bck.domain.campaign.dto.CampaignResponseDto;


public interface CampaignService {

    public CampaignResponseDto getCampaign(Long id);
}
