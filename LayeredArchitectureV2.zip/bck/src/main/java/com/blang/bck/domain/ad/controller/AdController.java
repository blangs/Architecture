package com.blang.bck.domain.ad.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.blang.bck.domain.ad.dto.AdResponseDto;
import com.blang.bck.domain.ad.service.AdService;
import com.blang.bck.global.common.codes.SuccessCode;
import com.blang.bck.global.common.response.ApiResponse;


@Controller
@RequestMapping("/app/publish")
public class AdController {

    private static final Logger logger = LoggerFactory.getLogger(AdController.class);
    private static final String RETURN_VIEW_URL = "jsp/web/DBD75039M00";

    @Inject
    private AdService adService;

	@RequestMapping(value = "/adServiceManagement")
	public String adServiceManagement(Model model, HttpServletRequest req) 
	{
		return RETURN_VIEW_URL;
	}
    
    @GetMapping("/ads/{id}")
    public ResponseEntity<AdResponseDto> getAd(@PathVariable Long id) {
    	AdResponseDto ad = adService.getAd(id);
    	return ResponseEntity.ok(ad);
    }
    
	@ResponseBody
	@RequestMapping(value = "/getAdServiceMngList", method = RequestMethod.POST)
	public Map<String, Object> getComCodeList(@RequestBody Map<String, Object> params, Model model, HttpServletRequest request) 
	{
		Map<String, Object> adInfo = adService.getAdList(params);
		System.out.println("adInfo: " + adInfo);
		
		model.addAllAttributes(adInfo);
		
		Map<String, Object> resultMap = new HashMap<String, Object>();
		return resultMap;
	}

	@ResponseBody
	@RequestMapping(value = "/getAdServiceMngList2", method = RequestMethod.POST)
	public ResponseEntity<ApiResponse<Object>> getComCodeList2(@RequestBody Map<String, Object> params, Model model, HttpServletRequest request) 
	{
		Map<String, Object> adInfo = adService.getAdList(params);
		System.out.println("adInfo: " + adInfo);
		
		model.addAllAttributes(adInfo);
		
		Map<String, Object> resultMap = new HashMap<String, Object>();

		return ApiResponse.of(SuccessCode.OK, resultMap);
	}
	
	
	
}