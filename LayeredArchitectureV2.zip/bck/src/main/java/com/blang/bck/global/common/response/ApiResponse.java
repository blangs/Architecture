package com.blang.bck.global.common.response;

import org.springframework.http.ResponseEntity;

import com.blang.bck.global.common.codes.SuccessCode;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.RequiredArgsConstructor;

/**
 * [공통] API Response 결과의 반환 값을 관리
 * 
 **/

/**
 * API서버 구성요소 중 응답이 있는데 Response구성하는 여러가지 방법 중 직접 Headerd와 body, ErrorCode를 써서 구성하는 방법.
 * 
 * @NoArgsConstructor
 * @NoArgsConstructor 어노테이션은 파라미터가 없는 디폴트 생성자를 자동으로 생성한다. 
 * 이 어노테이션을 사용하면, 클래스에 명시적으로 선언된 생성자가 없더라도 인스턴스를 생성할 수 있다.
 * 
 * @AllArgsConstructor
 * @AllArgsConstructor 어노테이션은 클래스의 모든 필드 값을 파라미터로 받는 생성자를 자동으로 생성한다. 
 * 이 어노테이션을 사용하면, 클래스의 모든 필드를 한 번에 초기화할 수 있다.
 * 
 * @RequiredArgsConstructor 사용 이유 
 * 초기화되지 않은 final 필드나 @NotNull 이 붙은 필드의 생성자를 자동 생성해주는 롬복 어노테이션.
 * 즉, 주로 의존성 주입(Dependency Injection) 편의성을위해서 사용된다.
 *  
 * @Autowired 를 필드마다 사용하면 코드가 지저분해진다. 
 * 롬북의 @RequiredArgsConstructor를 사용하면 생성자 주입을 통해 이러한 문제를 해결하고, 
 * 코드를 더 깨끗하고 일관성 있게 유지할 수 있다.
 * 
 * 큰 특징은 불변성이다.
 * @Autowired를 사용하면, 필드 주입이나 세터 주입 방식에서는 필드를 final로 선언할 수 없다. 
 * 반면, @RequiredArgsConstructor는 생성자 주입만을 하기 때문에, final로 선언할 수 있어 객체가 생성된 후 필드의 값이 변경되지 않도록 보장할 수 있다.
 * 
 */
@Getter
@AllArgsConstructor
@RequiredArgsConstructor
public class ApiResponse<T> {

    // API 응답 코드 Response
    private final int resultCode;
    // API 응답 코드 Message
    private final String resultMsg;
    // API 응답 결과 Response
    private T result;

    /**
     * Response 전송 타입-1
     * @param success 응답으로 반환하고싶은 성공상태코드
     * @return 성공상태코드, 성공메세지
     */
 	public static ResponseEntity<ApiResponse> of(SuccessCode success) {
        return ResponseEntity.status(success.getStatus())
                .body(new ApiResponse(success.getStatus(), success.getMessage()));
    }

 	/**
 	 * Response 전송 타입-2
 	 * @param success 응답으로 반환하고싶은 성공상태코드
 	 * @param <T> 응답으로 반환하고싶은 데이터
 	 * @param result 
 	 * @return 명시한 성공상태코드, 명시한 성공메세지, 응답데이터
 	 */
    public static <T> ResponseEntity<ApiResponse<T>> of(SuccessCode success, T result) {
        return ResponseEntity.status(success.getStatus())
        		.body(new ApiResponse<T>(success.getStatus(), success.getMessage(), result));
    }

    /**
     * Response 전송 타입-3
     * @param <T> 응답으로 반환하고 싶은 데이터
     * @param result 성공상태코드, 성공상태 코드간 구분코드, 응답데이터
     * @return 성공상태코드(200), 성공메세지(200), 응답데이터
     */
    public static <T> ResponseEntity<ApiResponse<T>> of(T result) {
        return ResponseEntity.status(SuccessCode.OK.getStatus())
                .body(new ApiResponse(SuccessCode.OK.getStatus(), SuccessCode.OK.getMessage(), result));
    }
}
